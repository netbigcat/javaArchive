import java.net.Socket;
import java.io.IOException;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.util.Scanner;
public class Client3{
    public static void main(String[] args) throws IOException{
        Socket socket = new Socket("localhost",8888);
        OutputStream os = socket.getOutputStream();
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        Scanner sn = new Scanner(System.in);
        os.write(sn.nextByte());        
        System.out.println(dis.readUTF());
        System.out.println(dis.readUTF());
        os.close();
        dis.close();
        socket.close();
    }
}


