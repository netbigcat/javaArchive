import java.net.Socket;
import java.io.IOException;
import java.io.OutputStream;
import java.io.DataInputStream;

public class Client1{
    public static void main(String[] args) throws IOException{
            Thread t = new Thread(){
                public void run(){
                    Socket socket = new Socket("172.18.51.126",8888);
                    OutputStream os = socket.getOutputStream();
                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    os.write(1);        
                    //char r = (char)is.read();
                    //System.out.println(dis.readUTF());
                    //char f = (char)is.read();
                    System.out.println(dis.readUTF());
                    os.close();
                    dis.close();
                }
            };
        
           t.start();
    }
}


