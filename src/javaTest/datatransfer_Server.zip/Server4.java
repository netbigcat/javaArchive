package datatransfer;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.DataOutputStream;

public class Server {
	static int stats_f = 0;
	static int analy_f = 0;
	public static synchronized int getStats_f() {
		return stats_f;
	}
	public static synchronized void setStats_f(int stats_f) {
		Server.stats_f = stats_f;
	}
	public static synchronized int getAnaly_f() {
		return analy_f;
	}
	public static synchronized void setAnaly_f(int analy_f) {
		Server.analy_f = analy_f;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket server;
		try {
			server = new ServerSocket(8888);
			while(true){
				Socket socket = server.accept();
				Thread socketT = new Thread(){
					public void run(){
						try {
							InputStream is = socket.getInputStream();
							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							char flag = 0;
							flag = (char)is.read();
							if(flag==1 && stats_f==0){
								stats_f = 1;
								new Datatransfer().stats();
								//dos.writeUTF("2");
								dos.writeInt(2);
								stats_f = 0;
							}
							if(flag==1 && stats_f==1){
								//dos.writeUTF("1");
								dos.writeInt(1);
							}
							if(flag==2 && analy_f==0){
								analy_f = 1;
								new Datatransfer().analy();
								//dos.writeUTF("2");
								dos.writeInt(2);
								analy_f = 0;
							}
							if(flag==2 && analy_f==1){
								//dos.writeUTF("1");
								dos.writeInt(1);
							}
							is.close();
							dos.close();
							socket.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}	
					}
				};
				socketT.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
