package datatransfer;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.DataOutputStream;
public class Server {	
	public static void main(String[] args){
		try {
			ServerSocket server = new ServerSocket(8888);
			while(true){
				Socket socket = server.accept();
				InputStream is = socket.getInputStream();
				DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
				char flag = 0;
				flag = (char)is.read();
				if(flag==1){
					dos.writeUTF("stats is runing!!");
					new Datatransfer().stats();
					dos.writeUTF("stats is finish!!");
				}
				if(flag==2){
					dos.writeUTF("analy is runing!!");
					new Datatransfer().analy();
					dos.writeUTF("analy is finish!!");
				}
				is.close();
				dos.close();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
