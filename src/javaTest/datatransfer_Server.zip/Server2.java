package datatransfer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.DataOutputStream;
public class Server {	
	public static void main(String[] args){
		Thread stats = new Thread(){
			public void run(){
			new Datatransfer().stats();
			}
        };
        Thread analy = new Thread(){
			public void run(){
				new Datatransfer().analy();
			}
		};
		try {
			ServerSocket server = new ServerSocket(8888);
			while(true){
				Socket socket = server.accept();
				Thread socketT = new Thread(){
					public void run(){
						try {
							InputStream is = socket.getInputStream();
							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							char flag = (char)is.read();
							if((flag==1) && (stats.isAlive())){								
								dos.writeUTF("stats is runing!!");
								dos.close();
							}
							if((flag==2) && (analy.isAlive())){
								dos.writeUTF("analy is runing!!");
								dos.close();
							}
							if((flag==1) && (!stats.isAlive())){
								stats.start();
								stats.join();
								dos.writeUTF("stats is finish!!");
								dos.close();
							}
							if((flag==2) && (!analy.isAlive())){
								analy.start();
								analy.join();
								dos.writeUTF("analy is finish!!");
								dos.close();
							}
							is.close();
						} catch (IOException | InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				};
				socketT.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

