import java.net.Socket;
import java.io.IOException;
import java.io.OutputStream;
import java.io.DataInputStream;

public class Client2{
    public static void main(String[] args) throws IOException{
        Socket socket = new Socket("172.18.51.126",8888);
        OutputStream os = socket.getOutputStream();
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        os.write(2);        
        //char r = (char)is.read();
        System.out.println(dis.readUTF());
        //char f = (char)is.read();
        os.close();
        dis.close();
        socket.close();
    }
}

