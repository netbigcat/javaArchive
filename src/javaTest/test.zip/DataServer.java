package datatransfer;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;

public class DataServer {
	public static void main(String[] args){
		try {
			ServerSocket server = new ServerSocket(8888);
			while(true){
				Socket socket = server.accept();
				InputStream is = socket.getInputStream();
				OutputStream os = socket.getOutputStream();
				if((int)is.read() == 1){
					
				}
				if((int)is.read() == 10){
					
				}
				if((int)is.read() == 2){
					
				}
				if((int)is.read() ==20){
					
				}
			
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
	}
}
