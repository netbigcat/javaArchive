package operation;

import java.sql.Connection;
import java.sql.SQLException;

import operation.DBConnection;
import java.sql.PreparedStatement;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;


public class TxtToMysql {
	public static void txtToMysql(){
		Connection conn = DBConnection.dbConnection();
		File file = new File("C:\\Users\\lenovo\\Desktop\\1004tempjavaIO\\qxk_pole_area.txt");
		FileReader fr = null;
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader bfr = new BufferedReader(fr);
		String s ;
		try {
			while((s=bfr.readLine()) != null){
				
				//System.out.println(s);
				String[] str = s.split("\t");
				/*int[] str = new int[str1.length];
				for(int i=0;i<str1.length;i++){
					str[i] = Integer.parseInt(str1[i].replace("\"",""));;
				}*/
				for(int i=0;i<str.length;i++){
					str[i] = str[i].replace("\"","");
				}

					try {
						String sql1 = "insert into test1 values(?,?,?,?,?)";
						PreparedStatement pstmt = conn.prepareStatement(sql1);
						/*pstmt.setInt(1,str[0]);
						pstmt.setInt(2,str[1]);
						pstmt.setInt(3,str[2]);
						pstmt.setInt(4,str[3]);
						pstmt.setInt(5,str[4]);
						*/
						pstmt.setString(1,str[0]);
						pstmt.setString(2,str[1]);
						pstmt.setString(3,str[2]);
						pstmt.setString(4,str[3]);
						pstmt.setString(5,str[4]);
						
						//System.out.println(str[1]);
						pstmt.executeUpdate();
					System.out.println(str[0]+" is imported to mysql");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				System.out.println();

				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		txtToMysql();
	}

}
