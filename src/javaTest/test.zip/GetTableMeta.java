package operation;
import operation.DBConnection;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.sql.ResultSet;

public class GetTableMeta {
	public static void main(String[] args){
		Connection conn = DBConnection.dbConnection();
		try {
			DatabaseMetaData dbmd = conn.getMetaData();
			ResultSet rs = dbmd.getColumns(conn.getCatalog(),null,"test",null); 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
