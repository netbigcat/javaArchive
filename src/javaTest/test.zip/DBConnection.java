package operation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection{
	public static Connection dbConnection(){
		Connection con = null;
		String driver = "com.mysql.jdbc.Driver";
		//String url    = "jdbc:mysql://172.18.51.115:3306/koala?useUnicode=true&characterEncoding=utf-8";
		String url    = "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf-8";
		String user   = "root";
		String pwd    = "";
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url,user,pwd);
			return con;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return con;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
}
