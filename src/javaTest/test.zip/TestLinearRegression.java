package test;

public class TestLinearRegression {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
         LinearRegression m = new LinearRegression("C:\\Users\\lenovo\\Desktop\\trainData.txt",0.001,1000000);
         m.printTrainData();
         m.trainTheta();
         m.printTheta();
    }

}