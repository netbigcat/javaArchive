package datatransfer;
import java.net.Socket;
import java.io.IOException;
import java.net.ServerSocket;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

public class TestThread extends Thread{
	static String flag = "0";
	public static void main(String[] args){
		Thread scan  = new Thread(){
			public void run(){
				try {
					ServerSocket server = new ServerSocket(8888);
					while(true){
						Socket socket = server.accept();
						//InputStream is = socket.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
						OutputStream os = socket.getOutputStream();
						flag=br.readLine();
						System.out.println(flag);
						Thread.sleep(1000);
					}
				} catch (IOException | InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		Thread run = new Thread(){
			public void run(){
				while(true){
					System.out.println("111111111111");
				}
			}
		};
		
		Thread decide = new Thread(){
			public void run(){
				while(true){
					if(flag == "1" && !run.isAlive()){
						run.start();
					}
					else if(flag == "1" && run.isAlive()){
						System.out.print("program is runing !!");
					}
					flag = "0";
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		};
//		run.start();
//		System.out.println(flag);
		//decide.start();
		scan.start();

	}
}

