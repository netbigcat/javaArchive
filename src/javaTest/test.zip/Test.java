package operation;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
public class Test {
	public static void main(String[] args) throws SQLException{
		Connection conn = DBConnection.dbConnection();
		DatabaseMetaData dbmd = conn.getMetaData();
		ResultSet columnSet = dbmd.getColumns(null, "%","mp", "%");
		ResultSetMetaData rsmd = columnSet.getMetaData();
		//System.out.println(rsmd.getColumnCount());
		for(int i=1;i<=rsmd.getColumnCount();i++){
			System.out.print(rsmd.getColumnName(i)+",");
		}
		System.out.println();
		columnSet.last();
		columnSet.first();
		while(columnSet.next()){
			for(int i=1;i<=rsmd.getColumnCount();i++){
				System.out.print(columnSet.getString(i)+",");
			}
			System.out.println();
		}
	}
}
