package operation;
import operation.DBConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;


public class MysqlTest{
	public static void main(String[] args){
		Connection conn = DBConnection.dbConnection();
		try {
			Statement stmt = conn.createStatement();
			String sql1 = "select * from test3";
			ResultSet rs = stmt.executeQuery(sql1);
			ResultSetMetaData rsmd = rs.getMetaData();
			int colnum = rsmd.getColumnCount();
			//System.out.println(rsmd.getColumnCount());
			//rs.last();
			//System.out.println(rs.getRow());
			int rownum = 0;
			while(rs.next()){
				rownum++;
			}
			//System.out.println(rownum);
			String[][] data = new String[rownum][colnum];
			rs = stmt.executeQuery(sql1);
			for(int i=0;rs.next();i++){
				for(int j=0;j < colnum;j++){
					data[i][j] = rs.getString(j+1);
				}
			}
			
			
			//System.out.println(data.length);
			//System.out.println(data[0].length);
			/*for(int i=0;i < data.length;i++){
				for(int j=0;j< data[0].length;j++){
					System.out.print(data[i][j]+"  ");					
				}
				System.out.println();
			}*/
			for(int i=0;i<data.length;i++){
				String sql2 = "select * from qxk_pole_area p where p.poleid = '"+data[i][0]+"'";
				//System.out.println(sql2);
				rs = stmt.executeQuery(sql2);
				while(rs.next()){
					System.out.println(rs.getString("wudongarea"));
				}
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}