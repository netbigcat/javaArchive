package test;

public class DoubleThread {
	 public static void main(String[] args) {
	  Thread t1 = new Thread() {
	   @Override
	   public void run() {
	    for (char i = 'a'; i <= 'z'; i++) {
	     System.out.println(i);
	    }
	   }
	  };
	  Thread t2 = new Thread() {
	   @Override
	   public void run() {
	    for (char i = 'A'; i <= 'Z'; i++) {
	     System.out.println(i);
	    }
	   }
	  };
	  t1.start();
	  t2.start();
	 }
	}