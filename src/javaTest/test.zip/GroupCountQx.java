package operation;
import operation.DBConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class GroupCountQx {
	public static void groupCountQx(){
		Connection conn = DBConnection.dbConnection();
		//String sql1 = "select * from test3";
		String sql1 = "select a.poleid,l.name,p.name towercode from t_yh_line l ,t_yh_pole p ,qxk_pole_area a where a.poleid = p.id and p.lineid = l.id";
		ResultSet rs = null;
		try {
			Statement stmt = conn.createStatement();
			rs = stmt.executeQuery(sql1);
			//System.out.println("sql1 is ok");
			while(rs.next()){
				 
				String sql2 = "select i.linename,i.towercode,i.defecttype,count(*)  from qxk_photo_info i where i.linename =?  and trim(leading '0' from replace(replace(i.towercode,'��',''),'��','')) = ? group by i.defecttype";
				PreparedStatement pstmt = conn.prepareStatement(sql2);
				pstmt.setString(1,rs.getString("name"));
				pstmt.setString(2,rs.getString("towercode").replace("#",""));
				ResultSet rs2 = pstmt.executeQuery();
				//System.out.println("sql2 is ok");
				while(rs2.next()){
					//System.out.println(rs.getString(1)+":"+rs2.getString(1)+":"+rs2.getString(2)+":"+rs2.getString(3));
					String column = null;
					if(rs2.getString("defecttype").equals("����")) column="defecttype1";
					else if(rs2.getString("defecttype").equals("������ʩ")) column="defecttype2";
					else if(rs2.getString("defecttype").equals("�������")) column="defecttype3";
					else if(rs2.getString("defecttype").equals("���")) column="defecttype4";
					else if(rs2.getString("defecttype").equals("��Ե��")) column="defecttype5";
					else if(rs2.getString("defecttype").equals("ϸС���")) column="defecttype6";
					else if(rs2.getString("defecttype").equals("����")) column="defecttype7";
					else if(rs2.getString("defecttype").equals("������")) column="defecttype8";
					else if(rs2.getString("defecttype").equals("ͨ������")) column="defecttype9";
					else if(rs2.getString("defecttype").equals("��������")) column="defecttype10";
					else if(rs2.getString("defecttype").equals("�����߽��")) column="defecttype8";
					else if(rs2.getString("defecttype").equals("����")) column="defecttype8";
					else if(rs2.getString("defecttype").equals("�������")) column="defecttype6";
					else if(rs2.getString("defecttype").equals("�������")) column="defecttype6";
					else if(rs2.getString("defecttype").equals("��·����")) column="defecttype9";
					else if(rs2.getString("defecttype").equals("��������")) column="defecttype10";
					else if(rs2.getString("defecttype").equals("����")) column="defecttype11";
					else if(rs2.getString("defecttype").equals("����")) column="defecttype11";
					else {
						System.out.println(rs2.getString("defecttype"));
						continue;
					}
					String sql3 = "update qxk_pole_area set "+column+" = ? where poleid = ?";
					PreparedStatement pstmt3 = conn.prepareStatement(sql3);
					pstmt3.setInt(1, Integer.parseInt(rs2.getString(4)));
					pstmt3.setInt(2,Integer.parseInt(rs.getString(1)));
					pstmt3.executeUpdate();
					System.out.println(rs.getString(1) + " is ok");
				}
			}
			
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
	public static void main(String[] args){
		groupCountQx();
		
	}

}
