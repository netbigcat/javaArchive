package datatransfer;

public class TestThread2 extends Thread{
	public void run(){
		
	}
}
